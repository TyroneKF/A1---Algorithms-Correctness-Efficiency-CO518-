import java.util.*; 

import java.lang.reflect.Array; 
/**
 * Write a description of class Tree_Sets here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Tree_Set extends IntSet
{

    private final  IntSet rightBranch; // could be a singleton, empty, treeset
    private final IntSet leftBranch; 

    /**
     * Constructor for objects of class Tree_Sets
     */
    public Tree_Set(IntSet leftBranch, IntSet rightBranch)
    {
        this.leftBranch = leftBranch;

        this.rightBranch = rightBranch;

    }

    public void printBranches()
    {

        System.out.println("\nLeft Branch: " + leftBranch.toString() + " Right Branch " + rightBranch.toString());

    }

    public String StringreturnRightObj()
    {
        return rightBranch.toString();
    }

    public IntSet returnRightObj()
    {
        return rightBranch;
    }

    public IntSet returnLeftObj()  
    {
        return leftBranch;
    }

    public String StringreturnLeftObj()
    {
        return leftBranch.toString();
    }

    public Tree_Set add(int x)
    {   // create a new tree each time you add to it
        // search tree if the number were adding contains that already 
        // check if the branch you need contains what you want 

        // these are used to temporarily store the values and change them 
        IntSet newRightBranch= this.rightBranch;
        IntSet newLeftBranch = this.leftBranch;
        if(contains(x))
        {
            System.out.format("The number %d is already in the tree structure.", x);
        }
        else
        {
            if(x %2 == 0)
            {  
                return new Tree_Set(newLeftBranch.add(x/2), newRightBranch);

            }
            else
            {   
                return new Tree_Set(newLeftBranch, newRightBranch.add(x/2));
            }
        }
        return this; // just here to satify the function
    }

    public boolean contains(int x)
    {   
        //if (x==0){return false;}
        if(x %2 == 0 && leftBranch.contains(x/2))
        {  
            return true;
        }
        else if (rightBranch.contains(x/2))
        {              
            return true;                  
        }
        return false;
    }

    public IntSet union(IntSet other)
    {   
        if(!(other instanceof Tree_Set))
        {
            return other.union(this);
        }
        else{
            Tree_Set other2 = (Tree_Set) other;       
            return new Tree_Set(leftBranch.union(other2.leftBranch), rightBranch.union(other2.rightBranch));
        }     

    }


    public String toString()
    {
        //return String.format("Left %d Right %d",rightBranch.toString(),leftBranch.toString());
        return  leftBranch.toString() +"  " +rightBranch.toString();  
    }

}
