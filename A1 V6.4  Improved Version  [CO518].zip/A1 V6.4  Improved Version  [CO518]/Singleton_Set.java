import java.util.*; 
/**
 * Write a description of class Singleton_Sets here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Singleton_Set extends IntSet
{
    private final  int value;
    private static IntSet[] setOfSingletons = new IntSet[8];

    /**
     * Constructor for objects of class Singleton_Sets
     */
    private Singleton_Set(int n) 
    {
        value =  n;
    }

    public static IntSet SConstructor(int n)
    //public static IntSet SConstructor(int n)
    {   // COULD BE OPTIMISED
        if(0<=n && 7>=n){

            if (setOfSingletons[n] == null){
                setOfSingletons[n] = new Singleton_Set(n);
            }
            return setOfSingletons[n];

        }

        return  new Singleton_Set(n);
    }

    public  IntSet add(int x)
    {   
        if(!this.contains(x))
        {
            return new Tree_Set(Empty_Set.Empty_Set(),Empty_Set.Empty_Set()).add(value).add(x);
        }
        else
        {
            return this;
        }
    }

    public   boolean contains(int x)
    {
        if(x == value)
        {
            return true;
        }
        return false;
    }

    public IntSet union(IntSet other)
    {
        return other.add(value);
    }

    public String toString()
    {   
        return String.format("{%d}", value);
    }
}
