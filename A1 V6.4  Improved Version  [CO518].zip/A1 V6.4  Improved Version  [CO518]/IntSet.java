
/**
 * Abstract class IntSet - write a description of the class here
 *
 * @author (your name here)
 * @version (version number or date here)
 */
public abstract class IntSet
{
    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public abstract IntSet add(int x);

    public abstract boolean contains(int x);

    public abstract IntSet union(IntSet other);
    
    public abstract String toString();
    
    


}
