
/**
 * Write a description of class EmptySet here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

// return empty set
public class Empty_Set extends IntSet
{
    static private final IntSet EmptyObj = new Empty_Set();
    /**
     * Constructor for objects of class EmptySet
     */
    public static IntSet Empty_Set()
    {
        return EmptyObj;

    }   

    public IntSet add(int x)
    {   
        return Singleton_Set.SConstructor(x);
    }

    public boolean contains(int x)
    {
       return false;
    }

    public IntSet union(IntSet other)
    {
        return other;
    }

    public String toString()
    {
        return "{}";
    }

}
